//Helper functions for code.

//Function to check if usingSTD is true or false
function usingSTDFunc(US){
	var std = '';
	if(US === true){
		
	}
	else {
		std = 'std::';
	}
	
	return std;
	
}