
var variableHUE = 330;

function typeConv(type){
	if(type == 'int'){
		return "Int";
	}
	if(type == 'size_t'){
		return "Size_t";
	}
	if(type == 'double'){
		return "Double";
	}
	if(type == 'float'){
		return "Float";
	}
	if(type == 'char'){
		return "Char";
	}
	if(type == 'string'){
		return "String";
	}
	if(type == 'bool'){
		return "Bool";
	}
}



Blockly.Blocks['variable_declare'] = {
	init: function() {
		
		this.appendValueInput("NAME")
			.appendField("Declare: ")
			.appendField(new Blockly.FieldDropdown([["int","myVarTypeInt"], ["size_t","myVarTypeSize_t"], ["double","myVarTypeDouble"], ["float","myVarTypeFloat"], ["char","myVarTypeChar"], ["string","myVarTypeString"], ["bool","myVarTypeBool"], ["auto","myVarTypeAuto"]]), "myVarType")
			.appendField(new Blockly.FieldVariable("myVar"), "myVarDec")
			.setCheck(["Int", "Size_t", "Double", "Float", "Char", "String", "Bool", "Auto", "Variable"]);
			
			this.appendDummyInput()
				.appendField("constant?")
				.appendField(new Blockly.FieldDropdown([["false","consFalse"], ["true","consTrue"] ]), "consType");
				
				
			this.setInputsInline(false);
			this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
		this.setColour(variableHUE);
		this.setTooltip("A standard variable declaration.");
		this.setHelpUrl("http://www.cplusplus.com/doc/tutorial/variables/");
		
		this.tag = '';
		
	},
	
	onchange: function(){
		Blockly.C.valueToCode(block, 'NAME', Blockly.C.ORDER_ATOMIC).setCheck(typeConv(this.getField('myVarType').getText()));
		
		//this.tag = (typeConv(this.getField('myVarType').getText()));
		
	}
	
};

Blockly.C['variable_declare'] = function(block) {
	var dropdown_myvartype = this.getField('myVarType').getText();
	
	var variable_myvardec = Blockly.C.variableDB_.getName(block.getFieldValue('myVarDec'), Blockly.Variables.NAME_TYPE);
	
	var value_name = Blockly.C.valueToCode(block, 'NAME', Blockly.C.ORDER_ATOMIC);
	
	var dropdown_cons = this.getField('consType').getText();
	
	// TODO: Assemble C into code variable.
	
	var code = '';
	var error = '//WRONG TYPE ERROR DECLARATION\n';
	var errorCheck = false;
	var initType = '';
	var initBlock = false;
	
	
	
	//if( block.getSurroundParent() && block.getSurroundParent().getField('myVarType').getText() == dropdown_myvartype ){
	//	initBlock = true;
	//}
	
	
	//if(value_name.length > 0 && initBlock == true){
	//	
	//	//Helper Function for warning
	//	function alert_WrongTypeWarning(TT){
	//		alert("Wrong type has been selected in variable declaration, possible loss of data:\n " + TT);
	//	}
	//	//Helper Function for error
	//	function alert_WrongType(TT){
	//		alert("Wrong type has been selected in variable declaration:\n " + TT);
	//	}
	//
	//	if(dropdown_myvartype != initType){
	//		var temp = (typeConv(dropdown_myvartype) + " declaration with " + initType + " initialization.");
	//		alert_WrongType(temp); 
	//		errorCheck = true;
	//	}
	//}
	//
	//if(errorCheck === true){
	//	code += error;
	//}
	
	
	//Done//
	if(dropdown_cons === 'true'){
		code += 'const ';
	}
	
	if(dropdown_myvartype === 'auto' && value_name.length < 1){
		code += dropdown_myvartype + ' ' + variable_myvardec + ' = 1';
	}
	else if(dropdown_myvartype === 'auto' && value_name.length > 0){
		code += dropdown_myvartype + ' ' + variable_myvardec + ' = ' + value_name;
	}
	else {
		if(usingSTD === false && dropdown_myvartype === 'string'){
			code += 'std::' + dropdown_myvartype + ' ' + variable_myvardec;
		}
		else {
			code += dropdown_myvartype + ' ' + variable_myvardec;
		}
		
		if(value_name.length > 0){
			code += ' = ' + value_name;
		}
	}
	
	if(dropdown_cons === 'true' && value_name.length < 1){
		
		if(dropdown_myvartype === 'int'){
			code += ' = 1';
		}
		if(dropdown_myvartype === 'size_t'){
			code += ' = 0';
		}
		if(dropdown_myvartype === 'double'){
			code += ' = 0.0';
		}
		if(dropdown_myvartype === 'float'){
			code += ' = 0.0';
		}
		if(dropdown_myvartype === 'char'){
			code += ' = \'a\'';
		}
		if(dropdown_myvartype === 'string'){
			code += ' = "myString"';
		}
		if(dropdown_myvartype === 'bool'){
			code += ' = true';
		}
		
	}
	
	
	code += ';\n'
	
	//Update tag type
	this.tag = (typeConv(this.getField('myVarType').getText()));
	
	//code += block.getSurroundParent( Workspace.getBlockById(var_initialization) );
	
	return code;
};

//Initialize the variable. Can be of any time. The code is a string literal.
Blockly.Blocks['var_initialization'] = {
	init: function() {
		this.appendDummyInput()
			.appendField("type: ")
			.appendField(new Blockly.FieldDropdown([["int","myVarTypeInt"], ["size_t","myVarTypeSize_t"], ["double","myVarTypeDouble"], ["float","myVarTypeFloat"], ["char","myVarTypeChar"], ["string","myVarTypeString"], ["bool","myVarTypeBool"]]), "myVarType");
		this.appendDummyInput()
			.appendField("input:")
			.appendField(new Blockly.FieldTextInput(""), "text1");
		this.setOutput(true, null);
		
		this.setInputsInline(true);
		this.setColour(variableHUE);
		this.setTooltip("");
		this.setHelpUrl("");
		
		//this.id = "var_initialization";
		
		//Sets the type that can be exported to other blocks
		this.tag = '1';
	},
	
	onchange: function(){
		
		this.setOutput(true, typeConv(this.getField('myVarType').getText()) );
		
		dropdown_drop1 = typeConv(this.getField('myVarType').getText());
		
		
	}
};

Blockly.C['var_initialization'] = function(block) {
	var dropdown_drop1 = typeConv(this.getField('myVarType').getText());
	var text_text1 = block.getFieldValue('text1');
	// TODO: Assemble C into code variable.
	var code = '';
	var error = "//WRONG TYPE ERROR INITIALIZATION\n";
	var errorCheck = false;
	
	//Helper Function for error
	function alert_WrongType(){
		alert("Wrong type has been selected in variable initialization.");
	}
	
	
	if(text_text1.length > 0){
		
		//Check type
		if(dropdown_drop1 == 'Int' || dropdown_drop1 == 'Size_t'){
			
			//If text_text1 is not a number
			if(isNaN(text_text1) == true){
				text_text1 = 0.0;
				alert_WrongType(); 
				errorCheck = true;
			}
			
			//Since it is Int/Size_t, round the down
			text_text1 = Math.floor(text_text1);
			
			//If type is Size_t, get the absolute value
			if(dropdown_drop1 == 'Size_t'){
				text_text1 = Math.abs(text_text1);
			}
			
		}
		
		//Check type
		if(dropdown_drop1 == 'Double' || dropdown_drop1 == 'Float'){
			if(isNaN(text_text1) == true){
				text_text1 = 0.0;
				alert_WrongType();
				errorCheck = true;
			}
		}
		
		//Check type
		if(dropdown_drop1 == 'Char'){
			if(typeof text_text1 === 'string'){
				text_text1 = "'" + text_text1.substring(0, 1) + "'";
			}
			else {
				text_text1 = "'a'";
				alert_WrongType();
				errorCheck = true;
			}
			
			
		}
		
		//Check type
		if(dropdown_drop1 == 'String'){
			if(typeof text_text1 === 'string'){
				text_text1 = '"' + text_text1 + '"';
			}
			else {
				text_text1 = "str";
				alert_WrongType(); 
				errorCheck = true;
			}
		}
		
		//Check type
		if(dropdown_drop1 == 'Bool'){
			if(text_text1 == 'true' || text_text1 == 'false'){
				
			}
			else {
				text_text1 = "true";
				alert_WrongType(); 
				errorCheck = true;
			}
		}
		
		
		
		code += text_text1;
		
		if( ( dropdown_drop1 == 'Double' || dropdown_drop1 == 'Float') && text_text1 % 1 === 0){
			code += ".0";
		}
	}
		
	
	// TODO: Change ORDER_NONE to the correct strength.
	return [code, Blockly.C.ORDER_NONE];
};


Blockly.Blocks['var_parse'] = {
  init: function() {
    this.appendValueInput("valinp1")
        .setCheck(null)
        .appendField(new Blockly.FieldVariable("myVar"), "myVarRef");
    this.setInputsInline(false);
    this.setOutput(true, "Variable");
    this.setColour(variableHUE);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.C['var_parse'] = function(block) {
	var variable_myvarref = Blockly.C.variableDB_.getName(block.getFieldValue('myVarRef'), Blockly.Variables.NAME_TYPE);
	var value_valinp1 = Blockly.C.valueToCode(block, 'valinp1', Blockly.C.ORDER_ATOMIC);
	// TODO: Assemble C into code variable.
	var code = '';
	
	code += variable_myvarref;
	
	if(value_valinp1.length > 0){
		code += ' ' + value_valinp1;
	}
	
	
	// TODO: Change ORDER_NONE to the correct strength.
	return [code, Blockly.C.ORDER_NONE];
};

Blockly.Blocks['var_change'] = {
  init: function() {
    this.appendValueInput("valinp1")
        .setCheck(["Number", "String", "Variable"])
        .appendField("Increment ")
        .appendField(new Blockly.FieldVariable("myVar"), "myVarDef")
		.appendField("by");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(variableHUE);
 this.setTooltip("Increment the variable.");
 this.setHelpUrl("");
  }
};

Blockly.C['var_change'] = function(block) {
	var variable_myvardef = Blockly.C.variableDB_.getName(block.getFieldValue('myVarDef'), Blockly.Variables.NAME_TYPE);
	var value_name = Blockly.C.valueToCode(block, 'valinp1', Blockly.C.ORDER_ATOMIC);
	// TODO: Assemble C into code variable.
	var code = '';
	
	code += variable_myvardef + " = " + variable_myvardef + " + " + value_name + ';\n';
	
	
	return code;
};

Blockly.Blocks['var_reinit'] = {
  init: function() {
    this.appendValueInput("valinp1")
        .setCheck()
        .appendField("Set ")
        .appendField(new Blockly.FieldVariable("myVar"), "myVarDef")
		.appendField("to");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(variableHUE);
 this.setTooltip("Sets the variable.");
 this.setHelpUrl("");
  }
};

Blockly.C['var_reinit'] = function(block) {
	var variable_myvardef = Blockly.C.variableDB_.getName(block.getFieldValue('myVarDef'), Blockly.Variables.NAME_TYPE);
	var value_name = Blockly.C.valueToCode(block, 'valinp1', Blockly.C.ORDER_ATOMIC);
	// TODO: Assemble C into code variable.
	var code = '';
	
	code += variable_myvardef + " = " + value_name + ';\n';
	
	return code;
};











